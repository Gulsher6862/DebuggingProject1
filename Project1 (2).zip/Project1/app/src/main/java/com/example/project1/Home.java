package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Home extends AppCompatActivity {

    ImageView v1,v2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        v1 = (ImageView)findViewById(R.id.imageView6);
        v1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmen();
            }
        });
        v2 = (ImageView)findViewById(R.id.imageView5);
        v2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openwomen();
            }
        });
    }

    private void openwomen() {
        Intent intent= new Intent(Home.this, women.class);
        startActivity(intent);
    }

    private void openmen() {
        Intent intent= new Intent(Home.this, Men.class);
        startActivity(intent);
    }
}